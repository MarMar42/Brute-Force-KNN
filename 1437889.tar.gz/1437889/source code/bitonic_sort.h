void compAndSwap(float*, int, int, int);
void bitonicMerge(float*, int, int, int);
void bitonicSort_seq(float*,int, int, int, int);
void bitonicSort_parT(float*, int, int, int, int);
void bitonicSort_parS(float* ,int , int , int, int);
int pow_of_2_less_than(int);
