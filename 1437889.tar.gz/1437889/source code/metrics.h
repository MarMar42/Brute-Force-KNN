float euclidDist(float*, float*, int);
float manHatDist(float*, float*, int);
