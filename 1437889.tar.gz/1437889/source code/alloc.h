void copy2dFloat(float**, float**, int , int );
float** alloc2dFloat(int , int );
int** alloc2dInt(int , int );
void copy2dInt(int**, int**, int, int);
float** fill2dFloatWithRand(float**, int , int );
int** fill2dIntWithSeq(int**, int , int );
float** create2DArray(int , int);
void free2dArray(float**,int);
