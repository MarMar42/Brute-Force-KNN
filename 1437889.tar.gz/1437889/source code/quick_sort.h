int partition(int,int, float*);

void q_sort_seq(int, int, float*, int);

void par_qsortS(int, int, float*);

void q_sort_parS(int, int, float*, int);

void par_qsortT(int, int, float*);

void q_sort_parT(int, int, float*, int);
