void merge(float*, int, int, int);
void mergeSort_seq(float*, int, int, int);
void mergeSort_parS(float*, int, int, int);
void mergeSort_parT(float*, int, int, int);

